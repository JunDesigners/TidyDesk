//go:build !windows

package main

import (
	"errors"
	"fmt"
	"os"
)

// Не-Windows сборка нужна только для разработки и тестов.
func openApp(url string) error {
	fmt.Fprintln(os.Stderr, url)
	return nil
}

func pickFolder() (string, error) { return "", errors.New("not supported") }

func openFolder(p string) {}
