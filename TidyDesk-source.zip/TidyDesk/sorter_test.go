package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func mk(t *testing.T, dir, name string, age time.Duration) {
	t.Helper()
	mkSize(t, dir, name, age, 1)
}

func mkSize(t *testing.T, dir, name string, age time.Duration, size int) {
	t.Helper()
	p := filepath.Join(dir, name)
	if err := os.WriteFile(p, []byte(strings.Repeat("x", size)), 0o644); err != nil {
		t.Fatal(err)
	}
	mt := time.Now().Add(-age)
	if err := os.Chtimes(p, mt, mt); err != nil {
		t.Fatal(err)
	}
}

func exists(p string) bool { _, err := os.Lstat(p); return err == nil }

func TestScanApplyUndo(t *testing.T) {
	t.Setenv("TIDYDESK_DATA", t.TempDir())
	dir := t.TempDir()
	old := 48 * time.Hour
	mk(t, dir, "photo.JPG", old)
	mk(t, dir, "report.pdf", old)
	mk(t, dir, "song.mp3", old)
	mk(t, dir, "setup.exe", old)
	mk(t, dir, "weird.xyz", old)
	mk(t, dir, "noext", old)
	mk(t, dir, "link.lnk", old)
	mk(t, dir, "movie.mp4.crdownload", old)
	mk(t, dir, "fresh.png", time.Minute)
	mk(t, dir, ".hidden", old)
	if err := os.Mkdir(filepath.Join(dir, "SomeFolder"), 0o755); err != nil {
		t.Fatal(err)
	}
	cfg := defaultSettings()

	res, err := scan(dir, cfg)
	if err != nil {
		t.Fatal(err)
	}
	if len(res.Items) != 6 {
		t.Fatalf("ожидали 6 файлов к перемещению, получили %d", len(res.Items))
	}
	for k, want := range map[string]int{"folders": 1, "recent": 1, "partial": 1, "shortcuts": 1, "system": 1} {
		if res.Skipped[k] != want {
			t.Errorf("skipped[%s]=%d, ждали %d", k, res.Skipped[k], want)
		}
	}

	r, err := apply(ApplyReq{Path: dir, Cfg: cfg, DisabledCats: []string{"audio"}, Excluded: []string{"noext"}})
	if err != nil || r.Entry == nil {
		t.Fatalf("apply: %v %+v", err, r)
	}
	if r.Entry.Count != 4 {
		t.Fatalf("ожидали 4 перемещения, получили %d", r.Entry.Count)
	}
	if !exists(filepath.Join(dir, "Изображения", "photo.JPG")) || !exists(filepath.Join(dir, "Документы", "report.pdf")) {
		t.Fatal("файлы не легли в папки")
	}
	if !exists(filepath.Join(dir, "song.mp3")) || !exists(filepath.Join(dir, "noext")) {
		t.Fatal("отключённое тронуто")
	}

	mk(t, dir, "report.pdf", old)
	r2, err := apply(ApplyReq{Path: dir, Cfg: cfg, DisabledCats: []string{"audio", "other", "images", "installers"}})
	if err != nil || r2.Entry == nil || r2.Entry.Count != 1 {
		t.Fatalf("apply#2: %v %+v", err, r2)
	}
	if !exists(filepath.Join(dir, "Документы", "report (1).pdf")) {
		t.Fatal("ожидали report (1).pdf")
	}

	rest, miss, err := undo(r2.Entry.ID)
	if err != nil || rest != 1 || miss != 0 {
		t.Fatalf("undo#2: %d %d %v", rest, miss, err)
	}
	if !exists(filepath.Join(dir, "report.pdf")) {
		t.Fatal("report.pdf не вернулся")
	}
	rest, _, err = undo(r.Entry.ID)
	if err != nil || rest != 4 {
		t.Fatalf("undo#1: %d %v", rest, err)
	}
	if !exists(filepath.Join(dir, "photo.JPG")) || !exists(filepath.Join(dir, "setup.exe")) {
		t.Fatal("файлы не вернулись")
	}
	if exists(filepath.Join(dir, "Изображения")) || exists(filepath.Join(dir, "Документы")) {
		t.Fatal("пустые папки не убраны")
	}
	if _, _, err := undo(r.Entry.ID); err == nil {
		t.Fatal("повторный откат должен давать ошибку")
	}
}

func TestGroupingAndForbidden(t *testing.T) {
	t.Setenv("TIDYDESK_DATA", t.TempDir())
	ts := time.Date(2025, 3, 9, 12, 0, 0, 0, time.Local)
	for g, want := range map[string]string{"none": "", "year": "2025", "month": "2025-03", "yearmonth": filepath.Join("2025", "03")} {
		dir := t.TempDir()
		mk(t, dir, "a.png", 24*time.Hour)
		if err := os.Chtimes(filepath.Join(dir, "a.png"), ts, ts); err != nil {
			t.Fatal(err)
		}
		cfg := defaultSettings()
		cfg.Group = g
		r, err := apply(ApplyReq{Path: dir, Cfg: cfg})
		if err != nil || r.Entry == nil {
			t.Fatal(g, err)
		}
		if !exists(filepath.Join(dir, "Изображения", want, "a.png")) {
			t.Fatalf("group=%s: файл не там", g)
		}
	}
	if _, err := scan(string(filepath.Separator), defaultSettings()); err == nil {
		t.Fatal("корень должен быть запрещён")
	}
}

func TestRulesFiltersAndCustomCats(t *testing.T) {
	t.Setenv("TIDYDESK_DATA", t.TempDir())
	dir := t.TempDir()
	old := 400 * 24 * time.Hour
	mk(t, dir, "Screenshot 2024-01-01.png", time.Hour*48)
	mk(t, dir, "holiday.png", time.Hour*48)
	mk(t, dir, "invoice_march.pdf", time.Hour*48)
	mk(t, dir, "notes.txt", old)
	mk(t, dir, "tiny.txt", time.Hour*48)
	mkSize(t, dir, "big.zip", time.Hour*48, 3*1024*1024)
	mk(t, dir, "keep_me.png", time.Hour*48)
	mk(t, dir, "temp.tmp", time.Hour*48)

	cfg := defaultSettings()
	cfg.Rules = []Rule{
		{ID: "old", Name: "Старьё", On: true, OlderDays: 365, Folder: "Архив/Старое", Color: palette[0]},
		{ID: "shots", Name: "Скриншоты", On: true, NameHas: "screenshot, снимок экрана", Folder: "Скриншоты", Color: palette[1]},
		{ID: "inv", Name: "Счета", On: true, Exts: ".pdf", NameHas: "inv*", Folder: "../../Счета", Color: palette[2]},
		{ID: "off", Name: "Выключено", On: false, Exts: "zip", Folder: "Нет", Color: palette[3]},
		{ID: "empty", Name: "Без условий", On: true, Folder: "Пусто", Color: palette[4]},
	}
	cfg.Cats["docs"] = CatCfg{Folder: "Бумаги", Exts: "txt, md"}
	cfg.Ignore = "keep_*, *.tmp"
	cfg.MinSizeKB = 0

	res, err := scan(dir, cfg)
	if err != nil {
		t.Fatal(err)
	}
	got := map[string]string{}
	for _, it := range res.Items {
		got[it.Name] = it.Target
	}
	want := map[string]string{
		"Screenshot 2024-01-01.png": "Скриншоты",
		"holiday.png":               "Изображения",
		"invoice_march.pdf":         "Счета",                          // ".." вычищено
		"notes.txt":                 filepath.Join("Архив", "Старое"), // правило старше категории
		"tiny.txt":                  "Бумаги",
		"big.zip":                   "Архивы", // выключенное правило не работает
	}
	for n, w := range want {
		if got[n] != w {
			t.Errorf("%s → %q, ждали %q", n, got[n], w)
		}
	}
	if _, ok := got["keep_me.png"]; ok {
		t.Error("keep_me.png должен быть проигнорирован")
	}
	if res.Skipped["ignored"] != 1 || res.Skipped["partial"] != 1 {
		t.Errorf("ignored=%d partial=%d, ждали 1 и 1", res.Skipped["ignored"], res.Skipped["partial"])
	}

	// Фильтр по размеру.
	cfg.MinSizeKB = 2
	res, _ = scan(dir, cfg)
	if len(res.Items) != 1 || res.Items[0].Name != "big.zip" {
		t.Fatalf("фильтр размера: %+v", res.Items)
	}
	cfg.MinSizeKB = 0
	cfg.MaxSizeMB = 1
	res, _ = scan(dir, cfg)
	for _, it := range res.Items {
		if it.Name == "big.zip" {
			t.Fatal("big.zip должен быть отфильтрован по максимуму")
		}
	}
}

func TestConflictSkipAndNormalize(t *testing.T) {
	t.Setenv("TIDYDESK_DATA", t.TempDir())
	dir := t.TempDir()
	if err := os.MkdirAll(filepath.Join(dir, "Документы"), 0o755); err != nil {
		t.Fatal(err)
	}
	mk(t, dir, "Документы/a.pdf", 48*time.Hour)
	mk(t, dir, "a.pdf", 48*time.Hour)
	mk(t, dir, "b.pdf", 48*time.Hour)
	cfg := defaultSettings()
	cfg.OnConflict = "skip"
	r, err := apply(ApplyReq{Path: dir, Cfg: cfg})
	if err != nil || r.Existing != 1 || r.Entry == nil || r.Entry.Count != 1 {
		t.Fatalf("skip: %v %+v", err, r)
	}
	if !exists(filepath.Join(dir, "a.pdf")) {
		t.Fatal("a.pdf должен остаться на месте")
	}

	var s Settings // пустые настройки превращаются в рабочие
	s.normalize()
	if s.Group != "none" || s.OnConflict != "rename" || s.Cats["images"].Folder != "Изображения" || s.Cats["images"].Exts == "" {
		t.Fatalf("normalize: %+v", s)
	}
	if sanitizeFolder(`C:\Windows/../a<b>/con`) != filepath.Join("C", "Windows", "ab", "_con") {
		t.Fatalf("sanitize: %q", sanitizeFolder(`C:\Windows/../a<b>/con`))
	}
	if err := saveSettings(s); err != nil {
		t.Fatal(err)
	}
	if loadSettings().Group != "none" {
		t.Fatal("load/save")
	}
}
