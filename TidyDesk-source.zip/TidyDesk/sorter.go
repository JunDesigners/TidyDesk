package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// ---------- Категории по умолчанию ----------

type baseCat struct{ ID, Name, Color, Exts string }

var baseCats = []baseCat{
	{"images", "Изображения", "#FF8F3F", "jpg jpeg png gif webp bmp svg heic heif tif tiff ico avif raw cr2 nef arw dng psd ai eps"},
	{"docs", "Документы", "#5B86FF", "pdf doc docx odt rtf txt md epub fb2 djvu mobi pages tex"},
	{"sheets", "Таблицы", "#2FBF8F", "xls xlsx xlsm csv ods ppt pptx odp key numbers tsv"},
	{"video", "Видео", "#F0508A", "mp4 mkv avi mov wmv webm flv m4v mpg mpeg 3gp"},
	{"audio", "Музыка", "#9A63F2", "mp3 wav flac aac ogg m4a wma opus aiff mid midi"},
	{"archives", "Архивы", "#E8C62A", "zip rar 7z tar gz bz2 xz iso img tgz cab"},
	{"installers", "Установщики", "#E8553F", "exe msi msix apk dmg pkg deb rpm appx"},
	{"code", "Код", "#17A2B8", "py js ts tsx jsx go json xml html htm css scss java c h cpp cs sql yaml yml sh bat ps1 ipynb rs php rb kt swift toml ini log"},
	{"fonts", "Шрифты", "#7C86A8", "ttf otf woff woff2 eot"},
	{"other", "Прочее", "#A7A9BD", ""},
}

var palette = []string{"#FF8F3F", "#5B86FF", "#2FBF8F", "#F0508A", "#9A63F2", "#E8C62A", "#E8553F", "#17A2B8", "#7C86A8", "#A7A9BD"}

type Category struct {
	ID     string `json:"id"`
	Name   string `json:"name"`
	Color  string `json:"color"`
	Folder string `json:"folder"`
	Off    bool   `json:"off"`
	Rule   bool   `json:"rule"`
}

// ---------- Настройки ----------

type CatCfg struct {
	Folder string `json:"folder"`
	Exts   string `json:"exts"`
	Off    bool   `json:"off"`
}

type Rule struct {
	ID        string  `json:"id"`
	Name      string  `json:"name"`
	On        bool    `json:"on"`
	Exts      string  `json:"exts"`
	NameHas   string  `json:"nameHas"`
	OlderDays int     `json:"olderDays"`
	MinMB     float64 `json:"minMB"`
	MaxMB     float64 `json:"maxMB"`
	Folder    string  `json:"folder"`
	Color     string  `json:"color"`
}

type Settings struct {
	Group      string            `json:"group"` // none | year | month | yearmonth
	MinAge     int               `json:"minAge"`
	MinSizeKB  int               `json:"minSizeKB"`
	MaxSizeMB  int               `json:"maxSizeMB"`
	Ignore     string            `json:"ignore"`
	OnConflict string            `json:"onConflict"` // rename | skip
	Cats       map[string]CatCfg `json:"cats"`
	Rules      []Rule            `json:"rules"`
}

func defaultSettings() Settings {
	s := Settings{Group: "none", MinAge: 10, OnConflict: "rename", Cats: map[string]CatCfg{}, Rules: []Rule{}}
	for _, b := range baseCats {
		s.Cats[b.ID] = CatCfg{Folder: b.Name, Exts: b.Exts}
	}
	return s
}

var reserved = map[string]bool{"con": true, "prn": true, "aux": true, "nul": true,
	"com1": true, "com2": true, "com3": true, "com4": true, "lpt1": true, "lpt2": true, "lpt3": true}

// sanitizeFolder делает из введённого текста безопасный относительный путь
// (без "..", дисков и запрещённых в Windows символов, не глубже 4 уровней).
func sanitizeFolder(p string) string {
	p = strings.ReplaceAll(p, "\\", "/")
	var parts []string
	for _, seg := range strings.Split(p, "/") {
		seg = strings.Map(func(r rune) rune {
			if r < 32 || strings.ContainsRune(`<>:"|?*`, r) {
				return -1
			}
			return r
		}, seg)
		seg = strings.Trim(seg, " .")
		if seg == "" {
			continue
		}
		if r := []rune(seg); len(r) > 60 {
			seg = strings.TrimRight(string(r[:60]), " .")
		}
		if reserved[strings.ToLower(seg)] {
			seg = "_" + seg
		}
		parts = append(parts, seg)
		if len(parts) == 4 {
			break
		}
	}
	return filepath.Join(parts...)
}

func splitBy(s string, seps string) []string {
	f := strings.FieldsFunc(s, func(r rune) bool { return strings.ContainsRune(seps, r) })
	out := make([]string, 0, len(f))
	for _, x := range f {
		if x = strings.TrimSpace(x); x != "" {
			out = append(out, x)
		}
	}
	return out
}

func splitExts(s string) []string {
	seen := map[string]bool{}
	var out []string
	for _, x := range splitBy(strings.ToLower(s), ", ;\n\r\t") {
		x = strings.TrimPrefix(strings.TrimPrefix(x, "*"), ".")
		if x != "" && !seen[x] {
			seen[x] = true
			out = append(out, x)
		}
	}
	return out
}

func splitTokens(s string) []string {
	return splitBy(strings.ToLower(s), ",;\n\r")
}

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func clampF(v, hi float64) float64 {
	if v < 0 || v != v {
		return 0
	}
	if v > hi {
		return hi
	}
	return v
}

func validColor(c string) bool {
	for _, p := range palette {
		if strings.EqualFold(p, c) {
			return true
		}
	}
	return false
}

func (s *Settings) normalize() {
	switch s.Group {
	case "none", "year", "month", "yearmonth":
	default:
		s.Group = "none"
	}
	s.MinAge = clampInt(s.MinAge, 0, 60*24*365)
	s.MinSizeKB = clampInt(s.MinSizeKB, 0, 1<<30)
	s.MaxSizeMB = clampInt(s.MaxSizeMB, 0, 1<<30)
	if s.OnConflict != "skip" {
		s.OnConflict = "rename"
	}
	if len(s.Ignore) > 4000 {
		s.Ignore = s.Ignore[:4000]
	}
	cats := map[string]CatCfg{}
	for _, b := range baseCats {
		c, ok := s.Cats[b.ID]
		if !ok {
			c = CatCfg{Folder: b.Name, Exts: b.Exts}
		}
		c.Folder = sanitizeFolder(c.Folder)
		if c.Folder == "" {
			c.Folder = b.Name
		}
		if b.ID == "other" {
			c.Exts = ""
		} else {
			c.Exts = strings.Join(splitExts(c.Exts), " ")
		}
		cats[b.ID] = c
	}
	s.Cats = cats
	if len(s.Rules) > 60 {
		s.Rules = s.Rules[:60]
	}
	seen := map[string]bool{}
	rules := make([]Rule, 0, len(s.Rules))
	for i, r := range s.Rules {
		r.ID = strings.TrimSpace(r.ID)
		if r.ID == "" || seen[r.ID] {
			r.ID = fmt.Sprintf("r%d-%d", time.Now().UnixNano()%100000, i)
		}
		seen[r.ID] = true
		r.Name = strings.TrimSpace(r.Name)
		if rn := []rune(r.Name); len(rn) > 40 {
			r.Name = string(rn[:40])
		}
		r.Folder = sanitizeFolder(r.Folder)
		if r.Folder == "" {
			r.Folder = sanitizeFolder(r.Name)
		}
		if r.Folder == "" {
			r.Folder = "Правила"
		}
		if r.Name == "" {
			r.Name = filepath.Base(r.Folder)
		}
		r.OlderDays = clampInt(r.OlderDays, 0, 36500)
		r.MinMB = clampF(r.MinMB, 1e7)
		r.MaxMB = clampF(r.MaxMB, 1e7)
		if len(r.NameHas) > 1000 {
			r.NameHas = r.NameHas[:1000]
		}
		r.Exts = strings.Join(splitExts(r.Exts), " ")
		if !validColor(r.Color) {
			r.Color = palette[i%len(palette)]
		}
		rules = append(rules, r)
	}
	s.Rules = rules
}

func settingsPath() string { return filepath.Join(dataDir(), "settings.json") }

func loadSettings() Settings {
	s := defaultSettings()
	if b, err := os.ReadFile(settingsPath()); err == nil {
		_ = json.Unmarshal(b, &s)
	}
	s.normalize()
	return s
}

func saveSettings(s Settings) error {
	if err := os.MkdirAll(dataDir(), 0o755); err != nil {
		return err
	}
	b, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	tmp := settingsPath() + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, settingsPath())
}

// ---------- Компиляция правил ----------

type cRule struct {
	id         string
	exts       map[string]bool
	names      []string
	olderDays  int
	minB, maxB int64
}

type compiled struct {
	s      Settings
	cats   []Category
	order  map[string]int
	extMap map[string]string
	rules  []cRule
	ignore []string
}

func globMatch(p, s string) bool {
	pr, sr := []rune(p), []rune(s)
	pi, si, star, mark := 0, 0, -1, 0
	for si < len(sr) {
		switch {
		case pi < len(pr) && (pr[pi] == '?' || pr[pi] == sr[si]):
			pi++
			si++
		case pi < len(pr) && pr[pi] == '*':
			star, mark = pi, si
			pi++
		case star >= 0:
			pi = star + 1
			mark++
			si = mark
		default:
			return false
		}
	}
	for pi < len(pr) && pr[pi] == '*' {
		pi++
	}
	return pi == len(pr)
}

func nameMatch(tok, low string) bool {
	if strings.ContainsAny(tok, "*?") {
		return globMatch(tok, low)
	}
	return strings.Contains(low, tok)
}

func compile(s Settings) *compiled {
	s.normalize()
	c := &compiled{s: s, order: map[string]int{}, extMap: map[string]string{}}
	add := func(cat Category) {
		c.order[cat.ID] = len(c.cats)
		c.cats = append(c.cats, cat)
	}
	for _, r := range s.Rules {
		cr := cRule{id: "rule:" + r.ID, names: splitTokens(r.NameHas), olderDays: r.OlderDays,
			minB: int64(r.MinMB * 1048576), maxB: int64(r.MaxMB * 1048576)}
		if ex := splitExts(r.Exts); len(ex) > 0 {
			cr.exts = map[string]bool{}
			for _, e := range ex {
				cr.exts[e] = true
			}
		}
		hasCond := cr.exts != nil || len(cr.names) > 0 || cr.olderDays > 0 || cr.minB > 0 || cr.maxB > 0
		if !r.On || !hasCond {
			continue
		}
		c.rules = append(c.rules, cr)
		add(Category{ID: cr.id, Name: r.Name, Color: r.Color, Folder: r.Folder, Rule: true})
	}
	for _, b := range baseCats {
		cc := s.Cats[b.ID]
		add(Category{ID: b.ID, Name: filepath.Base(cc.Folder), Color: b.Color, Folder: cc.Folder, Off: cc.Off})
		for _, e := range splitExts(cc.Exts) {
			if _, ok := c.extMap[e]; !ok {
				c.extMap[e] = b.ID
			}
		}
	}
	c.ignore = splitTokens(s.Ignore)
	return c
}

func (c *compiled) classify(low, ext string, size int64, mod, now time.Time) string {
	for _, r := range c.rules {
		if r.exts != nil && !r.exts[ext] {
			continue
		}
		if len(r.names) > 0 {
			ok := false
			for _, t := range r.names {
				if nameMatch(t, low) {
					ok = true
					break
				}
			}
			if !ok {
				continue
			}
		}
		if r.olderDays > 0 && now.Sub(mod) < time.Duration(r.olderDays)*24*time.Hour {
			continue
		}
		if r.minB > 0 && size < r.minB {
			continue
		}
		if r.maxB > 0 && size > r.maxB {
			continue
		}
		return r.id
	}
	if id, ok := c.extMap[ext]; ok {
		return id
	}
	return "other"
}

func groupDir(g string, t time.Time) string {
	switch g {
	case "year":
		return t.Format("2006")
	case "month":
		return t.Format("2006-01")
	case "yearmonth":
		return filepath.Join(t.Format("2006"), t.Format("01"))
	}
	return ""
}

// ---------- Сканирование ----------

type Item struct {
	Name   string `json:"name"`
	Size   int64  `json:"size"`
	Mod    int64  `json:"mod"`
	Ext    string `json:"ext"`
	Cat    string `json:"cat"`
	Target string `json:"target"`
}

type ScanResult struct {
	Path    string         `json:"path"`
	Cats    []Category     `json:"cats"`
	Items   []Item         `json:"items"`
	Skipped map[string]int `json:"skipped"`
}

var partialExt = map[string]bool{"crdownload": true, "part": true, "tmp": true, "download": true, "partial": true, "opdownload": true}
var shortcutExt = map[string]bool{"lnk": true, "url": true, "webloc": true}
var systemNames = map[string]bool{"desktop.ini": true, "thumbs.db": true, ".ds_store": true}

func forbidden(dir string) error {
	clean := filepath.Clean(dir)
	if filepath.Dir(clean) == clean {
		return errors.New("Корень диска трогать небезопасно. Выберите конкретную папку.")
	}
	low := strings.ToLower(clean)
	for _, env := range []string{"WINDIR", "ProgramFiles", "ProgramFiles(x86)", "ProgramData"} {
		if p := os.Getenv(env); p != "" {
			pl := strings.ToLower(filepath.Clean(p))
			if low == pl || strings.HasPrefix(low, pl+string(filepath.Separator)) {
				return errors.New("Системные папки не сортируем. Выберите папку со своими файлами.")
			}
		}
	}
	return nil
}

func scan(dir string, s Settings) (*ScanResult, error) {
	if err := forbidden(dir); err != nil {
		return nil, err
	}
	st, err := os.Stat(dir)
	if err != nil || !st.IsDir() {
		return nil, errors.New("Папка не найдена. Проверьте путь и попробуйте снова.")
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, errors.New("Нет доступа к этой папке.")
	}
	c := compile(s)
	res := &ScanResult{Path: dir, Cats: c.cats, Items: []Item{}, Skipped: map[string]int{}}
	now := time.Now()
	for _, e := range entries {
		name := e.Name()
		low := strings.ToLower(name)
		if e.IsDir() {
			res.Skipped["folders"]++
			continue
		}
		info, err := e.Info()
		if err != nil || !info.Mode().IsRegular() {
			res.Skipped["system"]++
			continue
		}
		if strings.HasPrefix(name, ".") || systemNames[low] {
			res.Skipped["system"]++
			continue
		}
		ext := strings.TrimPrefix(filepath.Ext(low), ".")
		if shortcutExt[ext] {
			res.Skipped["shortcuts"]++
			continue
		}
		if partialExt[ext] {
			res.Skipped["partial"]++
			continue
		}
		if c.s.MinAge > 0 && now.Sub(info.ModTime()) < time.Duration(c.s.MinAge)*time.Minute {
			res.Skipped["recent"]++
			continue
		}
		if (c.s.MinSizeKB > 0 && info.Size() < int64(c.s.MinSizeKB)*1024) ||
			(c.s.MaxSizeMB > 0 && info.Size() > int64(c.s.MaxSizeMB)*1048576) {
			res.Skipped["filtered"]++
			continue
		}
		ignored := false
		for _, t := range c.ignore {
			if nameMatch(t, low) {
				ignored = true
				break
			}
		}
		if ignored {
			res.Skipped["ignored"]++
			continue
		}
		catID := c.classify(low, ext, info.Size(), info.ModTime(), now)
		folder := c.cats[c.order[catID]].Folder
		target := filepath.Join(folder, groupDir(c.s.Group, info.ModTime()))
		res.Items = append(res.Items, Item{
			Name: name, Size: info.Size(), Mod: info.ModTime().Unix(),
			Ext: ext, Cat: catID, Target: target,
		})
	}
	sort.SliceStable(res.Items, func(i, j int) bool {
		a, b := res.Items[i], res.Items[j]
		if a.Cat != b.Cat {
			return c.order[a.Cat] < c.order[b.Cat]
		}
		return strings.ToLower(a.Name) < strings.ToLower(b.Name)
	})
	return res, nil
}

// ---------- История ----------

type Move struct {
	From string `json:"from"`
	To   string `json:"to"`
}

type SumItem struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Color string `json:"color"`
	Count int    `json:"count"`
}

type Entry struct {
	ID      string    `json:"id"`
	Dir     string    `json:"dir"`
	Time    int64     `json:"time"`
	Count   int       `json:"count"`
	Summary []SumItem `json:"summary"`
	Moves   []Move    `json:"moves"`
	Undone  bool      `json:"undone"`
}

type HistItem struct {
	ID     string `json:"id"`
	Dir    string `json:"dir"`
	Time   int64  `json:"time"`
	Count  int    `json:"count"`
	Undone bool   `json:"undone"`
}

var histMu sync.Mutex

func dataDir() string {
	if p := os.Getenv("TIDYDESK_DATA"); p != "" {
		return p
	}
	base, err := os.UserConfigDir()
	if err != nil {
		base = os.TempDir()
	}
	return filepath.Join(base, "TidyDesk")
}

func histPath() string { return filepath.Join(dataDir(), "history.json") }

func loadHistory() []Entry {
	b, err := os.ReadFile(histPath())
	if err != nil {
		return nil
	}
	var h []Entry
	_ = json.Unmarshal(b, &h)
	return h
}

func saveHistory(h []Entry) error {
	if len(h) > 25 {
		h = h[len(h)-25:]
	}
	if err := os.MkdirAll(dataDir(), 0o755); err != nil {
		return err
	}
	b, err := json.Marshal(h)
	if err != nil {
		return err
	}
	tmp := histPath() + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, histPath())
}

func historyList() []HistItem {
	histMu.Lock()
	defer histMu.Unlock()
	h := loadHistory()
	out := make([]HistItem, 0, len(h))
	for i := len(h) - 1; i >= 0; i-- {
		e := h[i]
		out = append(out, HistItem{e.ID, e.Dir, e.Time, e.Count, e.Undone})
	}
	return out
}

// ---------- Перемещение ----------

type ApplyReq struct {
	Path         string   `json:"path"`
	Cfg          Settings `json:"cfg"`
	DisabledCats []string `json:"disabledCats"`
	Excluded     []string `json:"excluded"`
}

type ApplyResult struct {
	Entry    *Entry   `json:"entry"`
	Errors   []string `json:"errors"`
	Existing int      `json:"existing"`
}

func uniquePath(p string) string {
	if _, err := os.Lstat(p); os.IsNotExist(err) {
		return p
	}
	dir, file := filepath.Split(p)
	ext := filepath.Ext(file)
	stem := strings.TrimSuffix(file, ext)
	for i := 1; ; i++ {
		c := filepath.Join(dir, fmt.Sprintf("%s (%d)%s", stem, i, ext))
		if _, err := os.Lstat(c); os.IsNotExist(err) {
			return c
		}
	}
}

func friendlyErr(err error) string {
	if os.IsPermission(err) {
		return "нет доступа"
	}
	m := strings.ToLower(err.Error())
	if strings.Contains(m, "being used") || strings.Contains(m, "sharing violation") {
		return "файл открыт в другой программе"
	}
	return "не удалось переместить"
}

func apply(req ApplyReq) (*ApplyResult, error) {
	cfg := req.Cfg
	cfg.normalize()
	res, err := scan(req.Path, cfg)
	if err != nil {
		return nil, err
	}
	off := map[string]bool{}
	for _, c := range req.DisabledCats {
		off[c] = true
	}
	skip := map[string]bool{}
	for _, n := range req.Excluded {
		skip[n] = true
	}
	counts := map[string]int{}
	var moves []Move
	var errs []string
	existing := 0
	for _, it := range res.Items {
		if off[it.Cat] || skip[it.Name] {
			continue
		}
		from := filepath.Join(req.Path, it.Name)
		toDir := filepath.Join(req.Path, it.Target)
		to := filepath.Join(toDir, it.Name)
		if _, err := os.Lstat(to); err == nil {
			if cfg.OnConflict == "skip" {
				existing++
				continue
			}
			to = uniquePath(to)
		}
		if err := os.MkdirAll(toDir, 0o755); err != nil {
			errs = append(errs, it.Name+": "+friendlyErr(err))
			continue
		}
		if err := os.Rename(from, to); err != nil {
			errs = append(errs, it.Name+": "+friendlyErr(err))
			continue
		}
		moves = append(moves, Move{from, to})
		counts[it.Cat]++
	}
	out := &ApplyResult{Errors: errs, Existing: existing}
	if len(moves) == 0 {
		return out, nil
	}
	e := &Entry{
		ID: fmt.Sprintf("%x", time.Now().UnixNano()), Dir: req.Path, Time: time.Now().Unix(),
		Count: len(moves), Moves: moves, Summary: []SumItem{},
	}
	for _, c := range res.Cats {
		if n := counts[c.ID]; n > 0 {
			e.Summary = append(e.Summary, SumItem{c.ID, c.Name, c.Color, n})
		}
	}
	histMu.Lock()
	h := append(loadHistory(), *e)
	_ = saveHistory(h)
	histMu.Unlock()
	out.Entry = e
	return out, nil
}

// ---------- Откат ----------

func undo(id string) (restored, missing int, err error) {
	histMu.Lock()
	defer histMu.Unlock()
	h := loadHistory()
	idx := -1
	for i := range h {
		if h[i].ID == id {
			idx = i
		}
	}
	if idx < 0 {
		return 0, 0, errors.New("Эта операция не найдена в истории.")
	}
	e := &h[idx]
	if e.Undone {
		return 0, 0, errors.New("Эта операция уже отменена.")
	}
	base := filepath.Clean(e.Dir)
	dirs := map[string]bool{}
	for i := len(e.Moves) - 1; i >= 0; i-- {
		m := e.Moves[i]
		if _, statErr := os.Lstat(m.To); statErr != nil {
			missing++
			continue
		}
		dest := uniquePath(m.From)
		if mkErr := os.MkdirAll(filepath.Dir(dest), 0o755); mkErr != nil {
			missing++
			continue
		}
		if rnErr := os.Rename(m.To, dest); rnErr != nil {
			missing++
			continue
		}
		restored++
		dirs[filepath.Dir(m.To)] = true
	}
	// Убираем опустевшие папки, которые создали сами (только внутри базовой).
	for d := range dirs {
		for cur := d; strings.HasPrefix(cur, base+string(filepath.Separator)); cur = filepath.Dir(cur) {
			if os.Remove(cur) != nil {
				break
			}
		}
	}
	e.Undone = true
	if sErr := saveHistory(h); sErr != nil {
		return restored, missing, sErr
	}
	return restored, missing, nil
}

// ---------- Пресеты папок ----------

type Preset struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Path  string `json:"path"`
	Loose int    `json:"loose"`
}

func presets() []Preset {
	home, err := os.UserHomeDir()
	if err != nil {
		return nil
	}
	exists := func(p string) bool { st, e := os.Stat(p); return e == nil && st.IsDir() }
	pick := func(cands ...string) string {
		for _, c := range cands {
			if c != "" && exists(c) {
				return c
			}
		}
		return ""
	}
	od := os.Getenv("OneDrive")
	list := []struct{ id, name, path string }{
		{"downloads", "Загрузки", pick(filepath.Join(home, "Downloads"))},
		{"desktop", "Рабочий стол", pick(filepath.Join(home, "Desktop"), filepath.Join(od, "Desktop"), filepath.Join(od, "Рабочий стол"))},
		{"documents", "Документы", pick(filepath.Join(home, "Documents"), filepath.Join(od, "Documents"), filepath.Join(od, "Документы"))},
	}
	cfg := loadSettings()
	var out []Preset
	for _, l := range list {
		if l.path == "" {
			continue
		}
		p := Preset{ID: l.id, Name: l.name, Path: l.path}
		if r, err := scan(l.path, cfg); err == nil {
			p.Loose = len(r.Items)
		}
		out = append(out, p)
	}
	return out
}
