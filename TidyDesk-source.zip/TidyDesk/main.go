package main

import (
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io/fs"
	"net"
	"net/http"
	"os"
	"strings"
	"sync/atomic"
	"time"
)

//go:embed web
var webFS embed.FS

var (
	token    string
	lastPing atomic.Int64
	byeAt    atomic.Int64
)

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}

// guard пускает только запросы с нашим одноразовым токеном и с локального адреса:
// посторонняя веб-страница не сможет дёргать API и двигать файлы.
func guard(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		t := r.Header.Get("X-Token")
		if t == "" {
			t = r.URL.Query().Get("t")
		}
		if t != token || !strings.HasPrefix(r.Host, "127.0.0.1:") {
			writeErr(w, http.StatusForbidden, "Нет доступа.")
			return
		}
		h(w, r)
	}
}

func decode(r *http.Request, v any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 1<<20)
	return json.NewDecoder(r.Body).Decode(v)
}

func main() {
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	token = hex.EncodeToString(b)

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		os.Exit(1)
	}
	port := ln.Addr().(*net.TCPAddr).Port

	sub, _ := fs.Sub(webFS, "web")
	indexHTML, _ := fs.ReadFile(sub, "index.html")
	page := strings.ReplaceAll(string(indexHTML), "__TOKEN__", token)

	mux := http.NewServeMux()

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		if r.URL.Query().Get("t") != token {
			http.Error(w, "Откройте TidyDesk через само приложение.", http.StatusForbidden)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		fmt.Fprint(w, page)
	})

	fonts := http.FileServer(http.FS(sub))
	mux.HandleFunc("/fonts/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "public, max-age=86400")
		fonts.ServeHTTP(w, r)
	})

	mux.HandleFunc("/api/ping", guard(func(w http.ResponseWriter, r *http.Request) {
		lastPing.Store(time.Now().UnixNano())
		byeAt.Store(0)
		writeJSON(w, 200, map[string]bool{"ok": true})
	}))

	// Окно закрыто: сигнал приходит через sendBeacon. Ждём пару секунд на случай обновления страницы.
	mux.HandleFunc("/api/bye", guard(func(w http.ResponseWriter, r *http.Request) {
		byeAt.Store(time.Now().UnixNano())
		writeJSON(w, 200, map[string]bool{"ok": true})
	}))

	mux.HandleFunc("/api/folders", guard(func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, map[string]any{"folders": presets()})
	}))

	mux.HandleFunc("/api/settings/load", guard(func(w http.ResponseWriter, r *http.Request) {
		type catDef struct {
			ID    string `json:"id"`
			Name  string `json:"name"`
			Color string `json:"color"`
			Exts  string `json:"exts"`
		}
		defs := make([]catDef, 0, len(baseCats))
		for _, b := range baseCats {
			defs = append(defs, catDef{b.ID, b.Name, b.Color, b.Exts})
		}
		writeJSON(w, 200, map[string]any{
			"settings": loadSettings(),
			"defaults": map[string]any{"settings": defaultSettings(), "cats": defs},
			"palette":  palette,
		})
	}))

	mux.HandleFunc("/api/settings/save", guard(func(w http.ResponseWriter, r *http.Request) {
		var s Settings
		if decode(r, &s) != nil {
			writeErr(w, 400, "Не удалось прочитать настройки.")
			return
		}
		s.normalize()
		if err := saveSettings(s); err != nil {
			writeErr(w, 500, "Не удалось сохранить настройки на диск.")
			return
		}
		writeJSON(w, 200, s)
	}))

	mux.HandleFunc("/api/pick", guard(func(w http.ResponseWriter, r *http.Request) {
		p, err := pickFolder()
		if err != nil {
			writeErr(w, 500, "Не получилось открыть окно выбора папки.")
			return
		}
		writeJSON(w, 200, map[string]string{"path": p})
	}))

	mux.HandleFunc("/api/scan", guard(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Path string   `json:"path"`
			Cfg  Settings `json:"cfg"`
		}
		if decode(r, &req) != nil {
			writeErr(w, 400, "Не удалось прочитать запрос.")
			return
		}
		res, err := scan(req.Path, req.Cfg)
		if err != nil {
			writeErr(w, 400, err.Error())
			return
		}
		writeJSON(w, 200, res)
	}))

	mux.HandleFunc("/api/apply", guard(func(w http.ResponseWriter, r *http.Request) {
		var req ApplyReq
		if decode(r, &req) != nil {
			writeErr(w, 400, "Не удалось прочитать запрос.")
			return
		}
		res, err := apply(req)
		if err != nil {
			writeErr(w, 400, err.Error())
			return
		}
		writeJSON(w, 200, res)
	}))

	mux.HandleFunc("/api/undo", guard(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			ID string `json:"id"`
		}
		if decode(r, &req) != nil {
			writeErr(w, 400, "Не удалось прочитать запрос.")
			return
		}
		restored, missing, err := undo(req.ID)
		if err != nil {
			writeErr(w, 400, err.Error())
			return
		}
		writeJSON(w, 200, map[string]int{"restored": restored, "missing": missing})
	}))

	mux.HandleFunc("/api/history", guard(func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, map[string]any{"items": historyList()})
	}))

	mux.HandleFunc("/api/open", guard(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Path string `json:"path"`
		}
		if decode(r, &req) != nil {
			writeErr(w, 400, "Не удалось прочитать запрос.")
			return
		}
		if st, err := os.Stat(req.Path); err != nil || !st.IsDir() {
			writeErr(w, 400, "Папка не найдена.")
			return
		}
		openFolder(req.Path)
		writeJSON(w, 200, map[string]bool{"ok": true})
	}))

	// Сторож: выходим, когда окно закрыто или о нём давно ничего не слышно.
	start := time.Now()
	go func() {
		for range time.Tick(time.Second) {
			now := time.Now().UnixNano()
			lp, bye := lastPing.Load(), byeAt.Load()
			switch {
			case bye > 0 && now-bye > int64(4*time.Second):
				os.Exit(0)
			case lp == 0 && time.Since(start) > 45*time.Second:
				os.Exit(0)
			case lp > 0 && now-lp > int64(5*time.Minute):
				os.Exit(0)
			}
		}
	}()

	url := fmt.Sprintf("http://127.0.0.1:%d/?t=%s", port, token)
	go func() { _ = openApp(url) }()

	_ = http.Serve(ln, mux)
}
