//go:build windows

package main

import (
	"encoding/base64"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
)

func hide(c *exec.Cmd) {
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}

// openApp открывает интерфейс в окне Edge/Chrome без адресной строки (режим --app).
func openApp(url string) error {
	pf, pf86, local := os.Getenv("ProgramFiles"), os.Getenv("ProgramFiles(x86)"), os.Getenv("LocalAppData")
	cands := []string{
		filepath.Join(pf86, `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(pf, `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(pf, `Google\Chrome\Application\chrome.exe`),
		filepath.Join(pf86, `Google\Chrome\Application\chrome.exe`),
		filepath.Join(local, `Google\Chrome\Application\chrome.exe`),
	}
	cache, err := os.UserCacheDir()
	if err != nil {
		cache = os.TempDir()
	}
	profile := filepath.Join(cache, "TidyDesk", "window")
	for _, b := range cands {
		if st, e := os.Stat(b); e != nil || st.IsDir() {
			continue
		}
		cmd := exec.Command(b,
			"--app="+url,
			"--window-size=1220,840",
			"--no-first-run",
			"--no-default-browser-check",
			"--disable-features=Translate",
			"--user-data-dir="+profile,
		)
		if cmd.Start() == nil {
			return nil
		}
	}
	// Запасной вариант: браузер по умолчанию.
	cmd := exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	hide(cmd)
	return cmd.Start()
}

// pickFolder показывает системное окно выбора папки.
func pickFolder() (string, error) {
	script := `Add-Type -AssemblyName System.Windows.Forms
$o = New-Object System.Windows.Forms.Form
$o.TopMost = $true
$o.ShowInTaskbar = $false
$o.StartPosition = 'CenterScreen'
$o.Size = New-Object System.Drawing.Size(0,0)
$f = New-Object System.Windows.Forms.FolderBrowserDialog
$f.Description = 'Выберите папку, которую нужно разложить'
$f.ShowNewFolderButton = $false
if ($f.ShowDialog($o) -eq 'OK') {
  [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($f.SelectedPath))
}`
	cmd := exec.Command("powershell", "-NoProfile", "-STA", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", script)
	hide(cmd)
	out, err := cmd.Output()
	if err != nil {
		return "", err
	}
	s := strings.TrimSpace(string(out))
	if s == "" {
		return "", nil
	}
	raw, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		return "", errors.New("bad dialog output")
	}
	return string(raw), nil
}

func openFolder(p string) {
	cmd := exec.Command("explorer", p)
	_ = cmd.Start()
}
