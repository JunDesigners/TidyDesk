module tidydesk

go 1.24.7
